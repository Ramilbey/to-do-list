const noButton = document.getElementById("no");
const image = document.getElementById("image");

noButton.addEventListener("mouseover", function () {
    const maxX = window.innerWidth - noButton.offsetWidth;
    const maxY = window.innerHeight - noButton.offsetHeight;
    const x = Math.random() * maxX;
    const y = Math.random() * maxY;
    noButton.style.left = `${x}px`;
    noButton.style.top = `${y}px`;
});

function displayImage() {
    image.style.display = "block"; // Show the image when "Yes" is pressed
    alert("I knew it! 😂");
}